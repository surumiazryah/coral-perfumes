<div class="content" style="margin-left: 40px;">
    <h2 style="text-align: center;margin-bottom: 0px">FORGOT</h2>
    <h3 style="text-align: center;margin-top: 0px;">YOUR PASSWORD ?</h3>
    <p style="text-align: center;padding-bottom: 20px;">Not to worry, we got you! Let's get you a new password.</p>
    <p style="text-align: center;"><a href="http://<?= Yii::$app->request->serverName ?>/site/new-password?token=<?= $val ?>" style="display: inline-block;cursor: pointer;padding: 6px 12px;font-size: 13px;line-height: 1.42857143;text-decoration: none;color: #fff;border-color: #80b636;background-color: #8dc63f;border: 1px solid transparent;">Reset Password</a></p>
</div>
